			<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>	
					<aside class="col-sm-4 col-md-4 sidebar">
						<?php dynamic_sidebar( 'sidebar-1' ); ?>
					</aside>
			<?php endif; ?>	