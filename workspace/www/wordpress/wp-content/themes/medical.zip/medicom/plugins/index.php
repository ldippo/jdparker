<?php 
// Speech is silver, silence is golden
?>